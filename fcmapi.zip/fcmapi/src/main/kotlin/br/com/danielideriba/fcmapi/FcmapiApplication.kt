package br.com.danielideriba.fcmapi

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class FcmapiApplication

fun main(args: Array<String>) {
	runApplication<FcmapiApplication>(*args)
}

